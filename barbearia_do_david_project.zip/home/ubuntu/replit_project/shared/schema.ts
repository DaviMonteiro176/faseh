import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  birthDate: text("birth_date"),
  cpf: text("cpf"),
  zipCode: text("zip_code"),
  address: text("address"),
  complement: text("complement"),
  city: text("city"),
  neighborhood: text("neighborhood"),
  state: text("state"),
  profilePhoto: text("profile_photo"),
  currentPlan: text("current_plan"),
  planStatus: text("plan_status").default("inactive"),
  planExpiry: text("plan_expiry"),
  loyaltyPoints: integer("loyalty_points").default(0),
  loyaltyLevel: text("loyalty_level").default("bronze"),
  availableCoupons: integer("available_coupons").default(0),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  serviceName: text("service_name").notNull(),
  barberName: text("barber_name").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  status: text("status").notNull().default("pending"),
  price: numeric("price"),
  duration: integer("duration"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const servicePlans = pgTable("service_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: numeric("price").notNull(),
  duration: integer("duration").notNull(),
  imageUrl: text("image_url"),
  isPopular: boolean("is_popular").default(false),
});

export const loyaltyBenefits = pgTable("loyalty_benefits", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  validUntil: text("valid_until"),
  pointsCost: integer("points_cost").default(0),
});

export const barbers = pgTable("barbers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialties: text("specialties").array(),
  isAvailable: boolean("is_available").default(true),
  photoUrl: text("photo_url"),
});

export const timeSlots = pgTable("time_slots", {
  id: serial("id").primaryKey(),
  barberId: integer("barber_id").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  isAvailable: boolean("is_available").default(true),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
});

export const insertServicePlanSchema = createInsertSchema(servicePlans).omit({
  id: true,
});

export const insertLoyaltyBenefitSchema = createInsertSchema(loyaltyBenefits).omit({
  id: true,
});

export const insertBarberSchema = createInsertSchema(barbers).omit({
  id: true,
});

export const insertTimeSlotSchema = createInsertSchema(timeSlots).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type ServicePlan = typeof servicePlans.$inferSelect;
export type InsertServicePlan = z.infer<typeof insertServicePlanSchema>;
export type LoyaltyBenefit = typeof loyaltyBenefits.$inferSelect;
export type InsertLoyaltyBenefit = z.infer<typeof insertLoyaltyBenefitSchema>;
export type Barber = typeof barbers.$inferSelect;
export type InsertBarber = z.infer<typeof insertBarberSchema>;
export type TimeSlot = typeof timeSlots.$inferSelect;
export type InsertTimeSlot = z.infer<typeof insertTimeSlotSchema>;
