import { useState, useEffect } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import HomePage from "@/pages/home";
import AppointmentsPage from "@/pages/appointments";
import PlansPage from "@/pages/plans";
import ProfilePage from "@/pages/profile";

export default function Dashboard() {
  const [currentPage, setCurrentPage] = useState("inicio");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Listen for custom events to close sidebar after actions
  useEffect(() => {
    const handleCloseSidebar = () => {
      setSidebarOpen(false);
    };

    window.addEventListener('closeSidebar', handleCloseSidebar);
    
    return () => {
      window.removeEventListener('closeSidebar', handleCloseSidebar);
    };
  }, []);

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "inicio":
        return <HomePage />;
      case "agendamentos":
        return <AppointmentsPage />;
      case "planos":
        return <PlansPage />;
      case "perfil":
        return <ProfilePage />;
      default:
        return <HomePage />;
    }
  };

  const getPageTitle = () => {
    const titles = {
      inicio: "Início",
      agendamentos: "Agendamentos",
      planos: "Planos", 
      perfil: "Perfil",
    };
    return titles[currentPage as keyof typeof titles] || "Início";
  };

  return (
    <div className="min-h-screen flex bg-background">
      <Sidebar 
        currentPage={currentPage} 
        onPageChange={setCurrentPage}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <main className="flex-1 lg:ml-0 ml-0 p-6 lg:p-8">
        <Header 
          title={getPageTitle()}
          onMenuClick={() => setSidebarOpen(true)}
        />
        <div className="mt-8">
          {renderCurrentPage()}
        </div>
      </main>
    </div>
  );
}
