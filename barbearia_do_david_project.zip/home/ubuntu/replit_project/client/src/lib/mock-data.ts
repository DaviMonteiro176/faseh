export const mockUser = {
  id: 1,
  username: "joao.silva",
  fullName: "João Silva Santos",
  email: "joao.silva@email.com",
  phone: "(11) 99999-9999",
  birthDate: "1990-05-15",
  cpf: "123.456.789-00",
  zipCode: "01234-567",
  address: "Rua das Flores, 123",
  complement: "Apt 45",
  city: "São Paulo",
  neighborhood: "Centro",
  state: "SP",
  currentPlan: "Corte e Barba Premium",
  planStatus: "active",
  planExpiry: "2024-02-15",
  loyaltyPoints: 1250,
  loyaltyLevel: "gold",
  availableCoupons: 3,
};

export const mockAppointments = [
  {
    id: 1,
    serviceName: "Corte e Barba",
    barberName: "David",
    date: "2024-01-15",
    time: "14:30",
    status: "confirmed",
    price: 75.00,
    duration: 90,
  },
  {
    id: 2,
    serviceName: "Ozônioterapia",
    barberName: "Carlos Mendes",
    date: "2024-01-22",
    time: "16:00",
    status: "pending",
    price: 40.00,
    duration: 45,
  },
];

export const mockServicePlans = [
  {
    id: 1,
    name: "Corte Clássico",
    description: "Corte tradicional com acabamento perfeito",
    price: 45.00,
    duration: 60,
    isPopular: false,
  },
  {
    id: 2,
    name: "Corte e Barba Premium",
    description: "Serviço completo com ozônioterapia incluída",
    price: 75.00,
    duration: 90,
    isPopular: true,
  },
  {
    id: 3,
    name: "Barba com Ozônioterapia",
    description: "Tratamento especializado para barba",
    price: 40.00,
    duration: 45,
    isPopular: false,
  },
];

export const mockLoyaltyBenefits = [
  {
    id: 1,
    title: "20% OFF - Restaurante Italiano",
    description: "Desconto especial no melhor restaurante italiano da região",
    category: "gastronomia",
    validUntil: "2024-03-31",
    pointsCost: 200,
  },
  {
    id: 2,
    title: "Mensalidade Grátis - Academia Forte",
    description: "Uma mensalidade gratuita na academia parceira",
    category: "esportes",
    validUntil: "2024-02-28",
    pointsCost: 500,
  },
];
