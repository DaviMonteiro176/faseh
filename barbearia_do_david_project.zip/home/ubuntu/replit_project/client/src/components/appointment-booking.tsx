import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Clock, User, Scissors } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AppointmentBookingProps {
  onClose?: () => void;
  onSuccess?: () => void;
}

export default function AppointmentBooking({ onClose, onSuccess }: AppointmentBookingProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedService, setSelectedService] = useState<string>("");
  const [selectedBarber, setSelectedBarber] = useState<string>("");
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>("");
  const [selectedTimeSlotId, setSelectedTimeSlotId] = useState<number>();

  // Fetch available services
  const { data: services } = useQuery({
    queryKey: ["/api/service-plans"],
  });

  // Fetch available barbers
  const { data: barbers } = useQuery({
    queryKey: ["/api/barbers"],
  });

  // Fetch available time slots based on selected barber and date
  const { data: timeSlots } = useQuery({
    queryKey: ["/api/time-slots", selectedBarber, selectedDate?.toISOString().split('T')[0]],
    enabled: !!selectedBarber && !!selectedDate,
    queryFn: () => {
      const dateStr = selectedDate?.toISOString().split('T')[0];
      return fetch(`/api/time-slots?barberId=${selectedBarber}&date=${dateStr}`).then(res => res.json());
    },
  });

  // Create appointment mutation
  const createAppointmentMutation = useMutation({
    mutationFn: async (appointmentData: any) => {
      return apiRequest("POST", "/api/appointments", appointmentData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/user/1"] });
      toast({
        title: "Agendamento criado",
        description: "Seu agendamento foi criado com sucesso!",
      });
      onSuccess?.();
      onClose?.();
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Não foi possível criar o agendamento. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!selectedDate || !selectedService || !selectedBarber || !selectedTimeSlot) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }

    const selectedServiceData = services?.find((s: any) => s.id.toString() === selectedService);
    const selectedBarberData = barbers?.find((b: any) => b.id.toString() === selectedBarber);

    const appointmentData = {
      userId: 1,
      serviceName: selectedServiceData?.name || "",
      barberName: selectedBarberData?.name || "",
      date: selectedDate.toISOString().split('T')[0],
      time: selectedTimeSlot,
      status: "pending",
      price: selectedServiceData?.price || "0.00",
      duration: selectedServiceData?.duration || 60,
    };

    createAppointmentMutation.mutate(appointmentData);
  };

  const isFormValid = selectedDate && selectedService && selectedBarber && selectedTimeSlot;

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold david-dark flex items-center gap-2">
          <Scissors className="w-6 h-6" />
          Novo Agendamento
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Service Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium david-dark">Serviço</label>
          <Select value={selectedService} onValueChange={setSelectedService}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um serviço" />
            </SelectTrigger>
            <SelectContent>
              {services?.map((service: any) => (
                <SelectItem key={service.id} value={service.id.toString()}>
                  <div className="flex items-center justify-between w-full">
                    <span>{service.name}</span>
                    <span className="text-sm text-david-gray ml-2">
                      R$ {parseFloat(service.price).toFixed(0)} - {service.duration}min
                    </span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Barber Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium david-dark">Barbeiro</label>
          <Select value={selectedBarber} onValueChange={setSelectedBarber}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um barbeiro" />
            </SelectTrigger>
            <SelectContent>
              {barbers?.map((barber: any) => (
                <SelectItem key={barber.id} value={barber.id.toString()}>
                  <div className="flex items-center gap-2">
                    <img
                      src={barber.photoUrl}
                      alt={barber.name}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-medium">{barber.name}</p>
                      <p className="text-xs text-david-gray">
                        {barber.specialties?.join(", ")}
                      </p>
                    </div>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Date Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium david-dark">Data</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !selectedDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? format(selectedDate, "dd/MM/yyyy") : "Selecione uma data"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => 
                  date < new Date() || 
                  date.getDay() === 0 || // Sunday
                  date > new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
                }
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Time Slot Selection */}
        {selectedBarber && selectedDate && (
          <div className="space-y-2">
            <label className="text-sm font-medium david-dark">Horário</label>
            {timeSlots && timeSlots.length > 0 ? (
              <div className="grid grid-cols-3 gap-2">
                {timeSlots.map((slot: any) => (
                  <Button
                    key={slot.id}
                    variant={selectedTimeSlot === slot.time ? "default" : "outline"}
                    size="sm"
                    onClick={() => {
                      setSelectedTimeSlot(slot.time);
                      setSelectedTimeSlotId(slot.id);
                    }}
                    className={
                      selectedTimeSlot === slot.time
                        ? "bg-david-dark text-david-cream"
                        : "hover:bg-david-light"
                    }
                  >
                    <Clock className="w-3 h-3 mr-1" />
                    {slot.time}
                  </Button>
                ))}
              </div>
            ) : (
              <p className="text-david-gray text-sm">
                Nenhum horário disponível para esta data.
              </p>
            )}
          </div>
        )}

        {/* Summary */}
        {isFormValid && (
          <Card className="bg-david-cream">
            <CardContent className="p-4">
              <h4 className="font-semibold david-dark mb-2">Resumo do Agendamento</h4>
              <div className="space-y-1 text-sm">
                <p>
                  <strong>Serviço:</strong> {services?.find((s: any) => s.id.toString() === selectedService)?.name}
                </p>
                <p>
                  <strong>Barbeiro:</strong> {barbers?.find((b: any) => b.id.toString() === selectedBarber)?.name}
                </p>
                <p>
                  <strong>Data:</strong> {selectedDate && format(selectedDate, "dd/MM/yyyy")}
                </p>
                <p>
                  <strong>Horário:</strong> {selectedTimeSlot}
                </p>
                <p>
                  <strong>Preço:</strong> R$ {services?.find((s: any) => s.id.toString() === selectedService)?.price}
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button
            onClick={handleSubmit}
            disabled={!isFormValid || createAppointmentMutation.isPending}
            className="flex-1 bg-david-dark hover:bg-david-gray text-david-cream"
          >
            {createAppointmentMutation.isPending ? "Agendando..." : "Confirmar Agendamento"}
          </Button>
          {onClose && (
            <Button
              variant="outline"
              onClick={onClose}
              disabled={createAppointmentMutation.isPending}
            >
              Cancelar
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}