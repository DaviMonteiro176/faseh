import { cn } from "@/lib/utils";
import { 
  Home, 
  Calendar, 
  Tags, 
  User, 
  LogOut,
  Menu,
  X
} from "lucide-react";
import logoImage from "@assets/Faustino_1749737135193.png";

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const navigationItems = [
  { id: "inicio", label: "Início", icon: Home },
  { id: "agendamentos", label: "Agendamentos", icon: Calendar },
  { id: "planos", label: "Planos", icon: Tags },
  { id: "perfil", label: "Perfil", icon: User },
];

export default function Sidebar({ currentPage, onPageChange, isOpen, onToggle }: SidebarProps) {
  const handleLogout = () => {
    if (confirm("Tem certeza que deseja sair?")) {
      console.log("Logging out...");
      // Close sidebar on mobile after logout action
      if (window.innerWidth < 1024) {
        onToggle();
      }
      // Implement logout logic here
    }
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onToggle}
          aria-label="Fechar menu"
        />
      )}
      {/* Mobile menu button */}
      <button
        className="lg:hidden fixed top-4 left-4 z-50 bg-david-dark text-white p-2 rounded-lg shadow-lg"
        onClick={onToggle}
        aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>
      {/* Sidebar */}
      <nav
        className={cn(
          "bg-white text-gray-700 w-64 min-h-screen fixed lg:relative lg:translate-x-0 transform transition-transform duration-300 ease-in-out z-50 shadow-lg",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo Section */}
        <div className="bg-david-dark flex items-center justify-center py-8 mb-0">
          <img 
            src={logoImage} 
            alt="Barbearia do David Logo" 
            className="h-24 w-auto object-contain"
          />
        </div>

        {/* Navigation Menu */}
        <div className="p-4">
          <ul className="space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      onPageChange(item.id);
                      if (window.innerWidth < 1024) {
                        onToggle();
                      }
                    }}
                    className={cn(
                      "w-full flex items-center space-x-3 p-3 rounded-lg font-medium transition-colors duration-200 text-gray-700",
                      isActive
                        ? "bg-gray-100 text-david-dark"
                        : "hover:bg-gray-50"
                    )}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
            
            <li className="pt-4 mt-4 border-t border-gray-200">
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 p-3 rounded-lg font-medium transition-colors duration-200 text-red-500 hover:bg-red-50"
              >
                <LogOut className="w-5 h-5" />
                <span>Sair</span>
              </button>
            </li>
          </ul>
        </div>
      </nav>
    </>
  );
}
