import { Bell } from "lucide-react";

interface HeaderProps {
  title: string;
  onMenuClick: () => void;
}

export default function Header({ title, onMenuClick }: HeaderProps) {
  return (
    <header className="mb-8 lg:ml-0 ml-12">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-dark-brown">{title}</h1>
          <p className="text-warm-gray mt-1">
            Bem-vindo de volta, <span className="font-medium">João Silva</span>
          </p>
        </div>
        
      </div>
    </header>
  );
}
