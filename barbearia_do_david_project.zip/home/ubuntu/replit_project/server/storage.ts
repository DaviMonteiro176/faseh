import { 
  users, appointments, servicePlans, loyaltyBenefits, barbers, timeSlots,
  type User, type InsertUser, 
  type Appointment, type InsertAppointment,
  type ServicePlan, type InsertServicePlan,
  type LoyaltyBenefit, type InsertLoyaltyBenefit,
  type Barber, type InsertBarber,
  type TimeSlot, type InsertTimeSlot
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;

  // Appointment methods
  getAppointmentsByUserId(userId: number): Promise<Appointment[]>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, updates: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;

  // Service Plan methods
  getAllServicePlans(): Promise<ServicePlan[]>;
  getServicePlan(id: number): Promise<ServicePlan | undefined>;

  // Loyalty Benefit methods
  getAllLoyaltyBenefits(): Promise<LoyaltyBenefit[]>;
  getLoyaltyBenefitsByCategory(category: string): Promise<LoyaltyBenefit[]>;

  // Barber methods
  getAllBarbers(): Promise<Barber[]>;
  getBarber(id: number): Promise<Barber | undefined>;

  // Time Slot methods
  getAvailableTimeSlots(barberId: number, date: string): Promise<TimeSlot[]>;
  bookTimeSlot(id: number): Promise<boolean>;
  generateTimeSlots(barberId: number, date: string): Promise<TimeSlot[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private appointments: Map<number, Appointment>;
  private servicePlans: Map<number, ServicePlan>;
  private loyaltyBenefits: Map<number, LoyaltyBenefit>;
  private barbers: Map<number, Barber>;
  private timeSlots: Map<number, TimeSlot>;
  private currentUserId: number;
  private currentAppointmentId: number;
  private currentServicePlanId: number;
  private currentLoyaltyBenefitId: number;
  private currentBarberId: number;
  private currentTimeSlotId: number;

  constructor() {
    this.users = new Map();
    this.appointments = new Map();
    this.servicePlans = new Map();
    this.loyaltyBenefits = new Map();
    this.barbers = new Map();
    this.timeSlots = new Map();
    this.currentUserId = 1;
    this.currentAppointmentId = 1;
    this.currentServicePlanId = 1;
    this.currentLoyaltyBenefitId = 1;
    this.currentBarberId = 1;
    this.currentTimeSlotId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize sample user
    const sampleUser: User = {
      id: 1,
      username: "joao.silva",
      password: "password123",
      fullName: "João Silva Santos",
      email: "joao.silva@email.com",
      phone: "(11) 99999-9999",
      birthDate: "1990-05-15",
      cpf: "123.456.789-00",
      zipCode: "01234-567",
      address: "Rua das Flores, 123",
      complement: "Apt 45",
      city: "São Paulo",
      neighborhood: "Centro",
      state: "SP",
      profilePhoto: null,
      currentPlan: "Corte e Barba Premium",
      planStatus: "active",
      planExpiry: "2024-02-15",
      loyaltyPoints: 1250,
      loyaltyLevel: "gold",
      availableCoupons: 3,
    };
    this.users.set(1, sampleUser);
    this.currentUserId = 2;

    // Initialize barbers
    const sampleBarbers: Barber[] = [
      {
        id: 1,
        name: "David",
        specialties: ["Corte Clássico", "Corte Moderno", "Barba"],
        isAvailable: true,
        photoUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      },
      {
        id: 2,
        name: "Carlos Mendes",
        specialties: ["Ozônioterapia", "Barba", "Corte Degradê"],
        isAvailable: true,
        photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      },
      {
        id: 3,
        name: "Roberto Silva",
        specialties: ["Corte Executivo", "Corte e Barba Premium"],
        isAvailable: true,
        photoUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      },
    ];

    sampleBarbers.forEach(barber => this.barbers.set(barber.id, barber));
    this.currentBarberId = 4;

    // Initialize service plans
    const plans: ServicePlan[] = [
      {
        id: 1,
        name: "Corte Clássico",
        description: "Corte tradicional com acabamento perfeito",
        price: "45.00",
        duration: 60,
        imageUrl: null,
        isPopular: false,
      },
      {
        id: 2,
        name: "Corte e Barba Premium",
        description: "Serviço completo com ozônioterapia incluída",
        price: "75.00",
        duration: 90,
        imageUrl: null,
        isPopular: true,
      },
      {
        id: 3,
        name: "Barba com Ozônioterapia",
        description: "Tratamento especializado para barba",
        price: "40.00",
        duration: 45,
        imageUrl: null,
        isPopular: false,
      },
      {
        id: 4,
        name: "Corte Moderno",
        description: "Estilos contemporâneos e tendências atuais",
        price: "55.00",
        duration: 75,
        imageUrl: "/attached_assets/new_corte_moderno.png",
        isPopular: false,
      },
      {
        id: 5,
        name: "Corte Degradê",
        description: "Técnicas de degradê e fade profissionais",
        price: "50.00",
        duration: 70,
        imageUrl: "/attached_assets/new_degrade.png",
        isPopular: false,
      },
      {
        id: 6,
        name: "Pacote Executivo",
        description: "Serviço completo para o homem moderno",
        price: "95.00",
        duration: 120,
        imageUrl: null,
        isPopular: false,
      },
    ];

    plans.forEach(plan => this.servicePlans.set(plan.id, plan));
    this.currentServicePlanId = 7;

    // Initialize loyalty benefits
    const benefits: LoyaltyBenefit[] = [
      {
        id: 1,
        title: "20% OFF - Restaurante Italiano",
        description: "Desconto especial no melhor restaurante italiano da região",
        category: "gastronomia",
        imageUrl: null,
        validUntil: "2024-03-31",
        pointsCost: 200,
      },
      {
        id: 2,
        title: "Mensalidade Grátis - Academia Forte",
        description: "Uma mensalidade gratuita na academia parceira",
        category: "esportes",
        imageUrl: null,
        validUntil: "2024-02-28",
        pointsCost: 500,
      },
    ];

    benefits.forEach(benefit => this.loyaltyBenefits.set(benefit.id, benefit));
    this.currentLoyaltyBenefitId = 3;

    // Initialize sample appointments
    const sampleAppointments: Appointment[] = [
      {
        id: 1,
        userId: 1,
        serviceName: "Corte e Barba",
        barberName: "David",
        date: "2024-01-15",
        time: "14:30",
        status: "confirmed",
        price: "75.00",
        duration: 90,
        createdAt: new Date(),
      },
      {
        id: 2,
        userId: 1,
        serviceName: "Ozônioterapia",
        barberName: "Carlos Mendes",
        date: "2024-01-22",
        time: "16:00",
        status: "pending",
        price: "40.00",
        duration: 45,
        createdAt: new Date(),
      },
    ];

    sampleAppointments.forEach(appointment => this.appointments.set(appointment.id, appointment));
    this.currentAppointmentId = 3;

    // Generate time slots for the next 30 days for all barbers
    const today = new Date();
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      const dateStr = date.toISOString().split('T')[0];
      
      sampleBarbers.forEach(barber => {
        this.generateTimeSlotsForDate(barber.id, dateStr);
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      phone: insertUser.phone ?? null,
      birthDate: insertUser.birthDate ?? null,
      cpf: insertUser.cpf ?? null,
      zipCode: insertUser.zipCode ?? null,
      address: insertUser.address ?? null,
      complement: insertUser.complement ?? null,
      city: insertUser.city ?? null,
      neighborhood: insertUser.neighborhood ?? null,
      state: insertUser.state ?? null,
      profilePhoto: insertUser.profilePhoto ?? null,
      currentPlan: insertUser.currentPlan ?? null,
      planStatus: insertUser.planStatus ?? "inactive",
      planExpiry: insertUser.planExpiry ?? null,
      loyaltyPoints: insertUser.loyaltyPoints ?? 0,
      loyaltyLevel: insertUser.loyaltyLevel ?? "bronze",
      availableCoupons: insertUser.availableCoupons ?? 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Appointment methods
  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(appointment => appointment.userId === userId);
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.currentAppointmentId++;
    const appointment: Appointment = { 
      ...insertAppointment, 
      id,
      status: insertAppointment.status ?? "pending",
      price: insertAppointment.price ?? null,
      duration: insertAppointment.duration ?? null,
      createdAt: new Date(),
    };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, updates: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...updates };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }

  // Service Plan methods
  async getAllServicePlans(): Promise<ServicePlan[]> {
    return Array.from(this.servicePlans.values());
  }

  async getServicePlan(id: number): Promise<ServicePlan | undefined> {
    return this.servicePlans.get(id);
  }

  // Loyalty Benefit methods
  async getAllLoyaltyBenefits(): Promise<LoyaltyBenefit[]> {
    return Array.from(this.loyaltyBenefits.values());
  }

  async getLoyaltyBenefitsByCategory(category: string): Promise<LoyaltyBenefit[]> {
    if (category === "tudo") {
      return this.getAllLoyaltyBenefits();
    }
    return Array.from(this.loyaltyBenefits.values()).filter(benefit => benefit.category === category);
  }

  // Barber methods
  async getAllBarbers(): Promise<Barber[]> {
    return Array.from(this.barbers.values()).filter(barber => barber.isAvailable);
  }

  async getBarber(id: number): Promise<Barber | undefined> {
    return this.barbers.get(id);
  }

  // Time Slot methods
  async getAvailableTimeSlots(barberId: number, date: string): Promise<TimeSlot[]> {
    return Array.from(this.timeSlots.values()).filter(
      slot => slot.barberId === barberId && slot.date === date && slot.isAvailable
    );
  }

  async bookTimeSlot(id: number): Promise<boolean> {
    const timeSlot = this.timeSlots.get(id);
    if (!timeSlot || !timeSlot.isAvailable) {
      return false;
    }
    
    const updatedSlot = { ...timeSlot, isAvailable: false };
    this.timeSlots.set(id, updatedSlot);
    return true;
  }

  async generateTimeSlots(barberId: number, date: string): Promise<TimeSlot[]> {
    return this.generateTimeSlotsForDate(barberId, date);
  }

  private generateTimeSlotsForDate(barberId: number, date: string): TimeSlot[] {
    const slots: TimeSlot[] = [];
    const workingHours = [
      "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
      "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30"
    ];

    workingHours.forEach(time => {
      const slot: TimeSlot = {
        id: this.currentTimeSlotId++,
        barberId,
        date,
        time,
        isAvailable: true,
      };
      slots.push(slot);
      this.timeSlots.set(slot.id, slot);
    });

    return slots;
  }
}

export const storage = new MemStorage();
