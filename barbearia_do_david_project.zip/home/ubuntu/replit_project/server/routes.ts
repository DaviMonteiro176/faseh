import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertAppointmentSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/user/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Appointment routes
  app.get("/api/appointments/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const appointments = await storage.getAppointmentsByUserId(userId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/appointments", async (req, res) => {
    try {
      const validatedData = insertAppointmentSchema.parse(req.body);
      const appointment = await storage.createAppointment(validatedData);
      res.status(201).json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Invalid appointment data" });
    }
  });

  app.put("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const appointment = await storage.updateAppointment(id, updates);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/appointments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteAppointment(id);
      if (!success) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.json({ message: "Appointment deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Service plan routes
  app.get("/api/service-plans", async (req, res) => {
    try {
      const plans = await storage.getAllServicePlans();
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/service-plans/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const plan = await storage.getServicePlan(id);
      if (!plan) {
        return res.status(404).json({ message: "Service plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Loyalty benefit routes
  app.get("/api/loyalty-benefits", async (req, res) => {
    try {
      const category = req.query.category as string;
      const benefits = category 
        ? await storage.getLoyaltyBenefitsByCategory(category)
        : await storage.getAllLoyaltyBenefits();
      res.json(benefits);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Barber routes
  app.get("/api/barbers", async (req, res) => {
    try {
      const barbers = await storage.getAllBarbers();
      res.json(barbers);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/barbers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const barber = await storage.getBarber(id);
      if (!barber) {
        return res.status(404).json({ message: "Barber not found" });
      }
      res.json(barber);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Time slot routes
  app.get("/api/time-slots", async (req, res) => {
    try {
      const barberId = parseInt(req.query.barberId as string);
      const date = req.query.date as string;
      
      if (!barberId || !date) {
        return res.status(400).json({ message: "barberId and date are required" });
      }

      const timeSlots = await storage.getAvailableTimeSlots(barberId, date);
      res.json(timeSlots);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/time-slots/:id/book", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.bookTimeSlot(id);
      
      if (!success) {
        return res.status(400).json({ message: "Time slot not available" });
      }
      
      res.json({ message: "Time slot booked successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
